my first mod
2025.01.30
---0.2v---
added large coal wall
coal block -> coal wall
2025.01.31
---0.3v---
added helium (sprite changed once)
2025.02.01
---0.4v---
added water electrolyzer, oxygen
2025.02.12
---0.5v---
added neon, argon, krypton, xenon, radon, oganesson
2025.02.14
---0.6v---
added reactor(test1) works with hydrogen
2025.02.15
---0.7v---
added sprites : test1
block name changed test1 -> hydrogen nuclear fusion reactor
hydrogen nuclear fusion reactor stats changed(now its more expensive than before and produces much more power)
2025.03.09
---0.8v---
sprite changed : HNFR
block health buffed, block size 5 -> 7
2025.03.16